import tkinter
from tkinter import *
import os
from os import *
import time
import random
from random import randint

Button_Pressed = False

def pressed():
	Button_Pressed = True
	while Button_Pressed == True:
		Choice = random.randint(1,5)
		Timer_Time_Maker = random.randint(1,30)
		for i in range(Timer_Time_Maker):
			 Timer_Time_Maker = Timer_Time_Maker - 1
			 time.sleep(1)
		if Choice == 1:
			os.system("Insult1.vbs")
		if Choice == 2:
			os.system("Insult2.vbs")
		if Choice == 3:
			os.system("Insult3.vbs")
		if Choice == 4:
			os.system("Insult4.vbs")
		

page = tkinter.Tk()

page.title("Hello Trash")

page.geometry("500x500")

Title = tkinter.Label(page, text="Press This Big Weird Button You Scumm", font=("arial")).place(x=100, y=50)

Button =tkinter.Button(page, text="Press Me You Trash", width=50, height=20, bg="red", command=pressed).place(x=75, y=100)



input()